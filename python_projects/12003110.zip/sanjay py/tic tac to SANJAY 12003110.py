board = {
    'A': ' ', 'B': ' ', 'C': ' ',
    'D': ' ', 'E': ' ', 'F': ' ',
    'G': ' ', 'H': ' ', 'I': ' '
}

player = 1
total_moves = 0
end_check = 0

X = input('player one name')
Y = input('player two name')


def check():
    if board['A'] == 'X' and board['B'] == 'X' and board['C'] == 'X':
        print(X + 'won !')
        return 1
    if board['D'] == 'X' and board['E'] == 'X' and board['F'] == 'X':
        print(X + 'won !')
        return 1
    if board['G'] == 'X' and board['H'] == 'X' and board['I'] == 'X':
        print(X + 'won !')
        return 1

    if board['A'] == 'X' and board['E'] == 'X' and board['I'] == 'X':
        print(X + 'won !')
        return 1
    if board['C'] == 'X' and board['E'] == 'X' and board['G'] == 'X':
        print(X + 'won !')
        return 1

    if board['A'] == 'X' and board['D'] == 'X' and board['G'] == 'X':
        print(X + 'won !')
        return 1
    if board['B'] == 'X' and board['E'] == 'X' and board['H'] == 'X':
        print(X + 'won !')
        return 1
    if board['C'] == 'X' and board['F'] == 'X' and board['I'] == 'X':
        print(X + 'won !')
        return 1

    if board['A'] == 'O' and board['B'] == 'O' and board['C'] == 'O':
        print(Y + 'won !')
        return 1
    if board['D'] == 'O' and board['E'] == 'O' and board['F'] == 'O':
        print(Y + 'won !')
        return 1
    if board['G'] == 'O' and board['H'] == 'O' and board['I'] == 'O':
        print(Y + 'won !')
        return 1
    if board['A'] == 'O' and board['E'] == 'O' and board['I'] == 'O':
        print(Y + 'won !')
        return 1
    if board['C'] == '0' and board['E'] == 'O' and board['G'] == 'O':
        print(X + 'won !')
        return 1
    if board['A'] == 'O' and board['D'] == 'O' and board['G'] == 'O':
        print(Y + 'won !')
        return 1
    if board['B'] == 'O' and board['E'] == 'O' and board['H'] == 'O':
        print(Y + 'won !')
        return 1
    if board['C'] == 'O' and board['F'] == 'O' and board['I'] == 'O':
        print(Y + 'won !')
        return 1
    return 0


print('A|B|C')
print('- +- +-')
print('D|E|F')
print('- +- +-')
print('G|H|I')
print('***')

while True:
    print(board['A'] + '|' + board['B'] + '|' + board['C'])
    print('-+-+-')
    print(board['D'] + '|' + board['E'] + '|' + board['F'])
    print('-+-+-')
    print(board['G'] + '|' + board['H'] + '|' + board['I'])
    end_check = check()
    if total_moves == 9 or end_check == 1:
        break
    while True:  # input from players
        if player == 1:  # choose player
            p1_input = input(X)
            if p1_input.upper() in board and board[p1_input.upper()] == ' ':
                board[p1_input.upper()] = 'X'
                player = 2
                break
            # on wrong input
            else:
                print('Invalid input, please try again')
                continue
        else:
            p2_input = input(Y)
            if p2_input.upper() in board and board[p2_input.upper()] == ' ':
                board[p2_input.upper()] = 'O'
                player = 1
                break
            else:  # on wrong input
                print('Invalid input, please try again')
                continue
    total_moves += 1
    print('***')
    print()