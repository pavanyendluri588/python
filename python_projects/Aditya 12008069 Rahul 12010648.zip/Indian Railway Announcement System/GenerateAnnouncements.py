import os
from typing import Mapping
import pandas as pd 
from pydub import AudioSegment
from gtts import gTTS     

def textToSpeechHindi(text, filename):
    mytext = str(text)
    language = 'hi' 
    myobj = gTTS(text=mytext, lang=language, slow=False)
    myobj.save(filename)
    
def textToSpeechEnglish(text, filename): 
    mytext = str(text)
    language = 'en'  
    myobj = gTTS(text=mytext, lang=language, slow=False)
    myobj.save(filename)
 
def mergeMP3(audios):
    combined = AudioSegment.empty()
    for audio in audios:
        combined += AudioSegment.from_mp3(audio)
    return combined

def generateSkeleton():
    
    audio = AudioSegment.from_mp3('railway_audio.mp3')

    # 1 - Generating intro in hindi.
    start = 0 * 1000
    finish = 2.9 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("1.mp3", format="mp3")
    
    # 16 - Generating intro and train number in english.
    start = 22.5 * 1000
    finish = 25.4 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("16.mp3", format="mp3")
    
    
    # 2 - Generating train number in hindi.
    start = 3 * 1000
    finish = 4 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("2.mp3", format="mp3") 
    
    # 5 - Generating se chalkar in hindi.
    start = 8.5 * 1000
    finish = 9.4 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("5.mp3", format="mp3") 
    
    # 19 - Generating from in english.
    start = 30.5 * 1000
    finish = 31.1 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("19.mp3", format="mp3") 
    
    # 7 - Generating ke raaste in hindi.
    start = 10.6 * 1000
    finish = 11.52 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("7.mp3", format="mp3") 
    
    # 23 - Generating via in english.
    start = 33.4 * 1000
    finish = 34 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("23.mp3", format="mp3") 
       
    # 9 - Generating ko jaane wali in hindi.
    start = 12 * 1000 
    finish = 12.95 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("9.mp3", format="mp3") 
    
    # 21 - Generating to in english.
    start = 32.3 * 1000 
    finish = 32.7 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("21.mp3", format="mp3") 
    
    
    # 11 - Generating apne nirdhaarit samay in hindi.
    start = 15.53 * 1000
    finish = 17 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("11.mp3", format="mp3") 
    
    # 27 - Generating at it scheduled time in english.
    start = 38.2 * 1000
    finish = 39.8 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("27.mp3", format="mp3") 
    
    # 13 - Generating platform number in hindi.
    start = 19.8 * 1000
    finish = 21 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("13.mp3", format="mp3") 
    
    # 25 - Generating will depart from platform in english.
    start = 35.4 * 1000
    finish = 37.6 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("25.mp3", format="mp3") 
    
    # 15 - Generating se jaayegi in hindi.
    start = 21.6 * 1000
    finish = 22.7 * 1000 
    audioProcessed = audio[start:finish]
    audioProcessed.export("15.mp3", format="mp3")
    

def generateAnnouncement(filename): 
    df = pd.read_excel(filename)
    print(df)
    for index, item in df.iterrows():
        # 3 - Generating train number reading in hindi.
        textToSpeechHindi(item['train_number'], '3.mp3')
        
        # 17 - Generating train number reading in english.
        textToSpeechEnglish(item['train_number'], '17.mp3') 
        
        # 4 - Generating first station in hindi.
        textToSpeechHindi(item['from'], '4.mp3')
        
        # 20 - Generating first station in english.
        textToSpeechEnglish(item['from'], '20.mp3')
        
        # 6 - Generating via station in hindi.
        textToSpeechHindi(item['via'], '6.mp3')
        
        # 24 - Generating via station in english.
        textToSpeechEnglish(item['via'], '24.mp3')
        
        # 8 - Generating last station in hindi.
        textToSpeechHindi(item['to'], '8.mp3')
        
        # 22 - Generating last station in english.
        textToSpeechEnglish(item['to'], '22.mp3')
        
        # 10 - Generating train name in hindi.
        textToSpeechHindi(item['train_name'], '10.mp3')
        
        # 18 - Generating train name in English.
        textToSpeechEnglish(item['train_name'], '18.mp3')
        
        # 12 - Generating time in hindi.
        textToSpeechHindi(item['time'], '12.mp3')
        
        # 28 - Generating time in english.
        textToSpeechEnglish(item['time'], '28.mp3')
        
        # 14 - Generating platform number reading in hindi.
        textToSpeechHindi(item['platform'], '14.mp3')
        
        # 26 - Generating platform number reading in english.
        textToSpeechEnglish(item['platform'], '26.mp3')
        
        audios = [f"{i}.mp3" for i in range(1,29)]

        announcement = mergeMP3(audios)
        announcement.export(f"{item['train_number'].replace(' ','')}.mp3", format="mp3") 
    

if __name__ == "__main__":
    print("Generating Skeleton...")
    generateSkeleton()
    print("Now Generating Announcement...")
    generateAnnouncement("announcement_list.xlsx")   

