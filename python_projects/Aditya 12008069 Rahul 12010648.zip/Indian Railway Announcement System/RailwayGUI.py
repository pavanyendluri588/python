# Now making Tkinter GUI

import tkinter as tk
from tkinter import ttk 
import pandas as pd 
import pygame
from tkinter import * 
from tkinter import messagebox    
from PIL import Image, ImageTk
import os.path
from os import path
 
# initalise the tkinter GUI 
root = tk.Tk()
root.title("IRAS")
root.geometry("1000x500") # set the root dimensions
root.pack_propagate(False) # tells the root to not let the widget inside it determine its size.
root.resizable(0, 0) # makes the root window fixed in size.

bg_image= ImageTk.PhotoImage(Image.open("bg_image.jpg")) 
img = Label(root, image=bg_image)
img.place(x=0,y=0,width=1000,height=500)

heading = Label(root, text="INDIAN RAILWAY ANNOUNCEMENT SYSTEM", font='Helvetica 18 bold' , pady=5)
heading.pack(anchor=N) 

frame1 = tk.LabelFrame(root, text="Announcement List" ,  relief= 'sunken' , font='bold' ,height=250)
frame1.pack(fill= BOTH, expand= True, padx= 20, pady=10) 
frame1.pack_propagate(0)
 
frame2 = tk.LabelFrame(root, height=70)
frame2.pack(fill= BOTH, expand= True, padx= 20) 
frame2.pack_propagate(0)

f2_image= ImageTk.PhotoImage(Image.open("frame3bg.jpg")) 
img = Label(frame2, image=f2_image) 
img.place(x=0,y=0)    
 
L1 = Label(frame2, text="Enter train number to be Announced :" , font="18")
L1.pack(pady=10)
E1 = Entry(frame2, bd =5)
E1.pack() 

def rewind_sound():
    pygame.mixer.music.rewind()
def stop_sound():
    pygame.mixer.music.pause()
def pause_sound():
    pygame.mixer.music.unpause()
           
pygame.mixer.init()
def play_sound(): 
    
    if ((E1.get()).strip()) == "": 
        messagebox.showwarning("This field cannot be blank","Please enter a valid train number")
    elif path.exists(E1.get()+".mp3"):
        pygame.mixer.music.load(E1.get()+".mp3") 
        pygame.mixer.music.play() 
    else:
        messagebox.showerror("File not found", "Train number you entered is invalid.\nPlease check the Announcement list and try again.") 
 
frame3 = tk.LabelFrame(root,height=80)
frame3.pack(fill= BOTH, expand= True, padx= 20)  
frame3.pack_propagate(0) 

f3_image= ImageTk.PhotoImage(Image.open("frame3bg.jpg"))  
img = Label(frame3 , image=f3_image)
img.place(x=0,y=0)  

b3 = Button(frame3, text="⏪ Rewind", font="25", command=rewind_sound) 
b3.grid(pady=15,padx=60,row=2,column=3) 
b1 = Button(frame3, text="⏯️ Generate Announcement", font="25", command=play_sound)
b1.grid(padx=60,row=2,column=4) 
b2 = Button(frame3, text="⏸ Pause", font="25", command=stop_sound)
b2.grid(padx=60,row=2,column=5) 
b4 = Button(frame3, text="▶ Play", font="25", command=pause_sound) 
b4.grid(padx=60,row=2,column=6) 
  
# Treeview Widget     
treeview = ttk.Treeview(frame1)
treeview.place(relheight=1, relwidth=1) # set the height and width of the widget to 100% of its container.

treescrolly = tk.Scrollbar(frame1, orient="vertical", command=treeview.yview) # command means update the yaxis view of the widget
treeview.configure(yscrollcommand=treescrolly.set) # assign the scrollbars to the Treeview Widget
treescrolly.pack(side="right", fill="y") # make the scrollbar fill the y axis of the Treeview widget

def Load_excel_data():
    file_path = "announcement_list.xlsx"
    df = pd.read_excel(file_path) 
    
    treeview["column"] = list(df.columns)
    treeview["show"] = "headings"
    for column in treeview["columns"]:
        treeview.heading(column, text=column) # column heading = column name

    df_rows = df.to_numpy().tolist() # turns the dataframe into a list of lists
    for row in df_rows:
        treeview.insert("", "end", values=row) # inserts each list into the treeview
    return None

Load_excel_data()

treeview.column(0, width=50)
treeview.column(1, width=100)
treeview.column(2, width=60) 
treeview.column(3, width=100)  
treeview.column(4, width=60)
treeview.column(5, width=100)
treeview.column(6, width=60)

root.mainloop()