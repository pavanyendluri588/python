#!/usr/bin/env python
# coding: utf-8

# In[10]:


print("Chat Buddy: What do you want me to call you?")
user_name = input()


# In[11]:


name = "Mr.Bot" 
weather = "cloudy" 
mood = "Happy"


# In[12]:


bot_template = name + " : {0}"
user_template = user_name + " : {0}"


# In[13]:


print("Now Chat with Chat Buddy")


# In[14]:


import random


# In[15]:


responses = { 
    "Hi":[
    "Hey!",
    "what's app",
    "Hello",],
    
    "Hello":[
    "hi",
    "Hey!",],
    
    "Will u be my friend?":[
    "Yes,ofcourse I have felt friendship is a gem.And to those who cares it it is the best thing in world.",],
    
    "What do you eat?":[
    "Iam a robot that's whay i can't eat anything.If i were a human being i like to eat fast foods.",],
    
    "What is your favorate food item?":[
    "Iam a robot that's whay i can't eat anything.If i were a human being i like to eat fast foods.",],
    
    "Are you a human":[
    "No, I am a robot with human feelings.",],
    
    "Good morning":[
    "Very good morning,Have a nice day!",],
    
    "Good afternoon":[
    "Good afternoon,Have a great day!",],
    
    "Good evening":[
    "Good evening,Have some tea or coffee for the refreshment.",],
    
    "Good night":[
    "Good night,it's time to ride the rainbow to dreamland!",],
    
    "Tell me a joke":[
    "How do robots eat food? With computer chips.",],
    
    "Tell me something":[
    "The pigeons in towns and cities have a natural habit of settling on the rocky landscape, where there are no trees. It means they don't inherit the sitting reflex. The structure of their limbs gives them an opportunity to sit in trees, but they haven't got used to such a behavior.",],
    
    "Do you like people?":[
    "Yes",],
    
    "Do you have friends?":[
    "In this is world every one is like my friend",],
    
    "Do you trust people":[
    "yeah no one could lie to me",],
    
    "Tell me about yourself":[
    "Basically, iam a chatbot.I was made by 3 Lpu students.There main moto is to make me as fiendly with all people.",],
    
    "Ok":[
    "yup!",],
    
    "Welcome":[
    "Most welcome!",],
    
    "Any advice for me":[
    "Be patient and persistent. Life is not so much what you accomplish as what you overcome. ",],
    
    "Do you have fellings?":[
    "Iam a robort,with human feelings",],
    
    "What is your favorite place?":[
    "Where the technology is improving day by day that's my favorite place.",],
    
    "What is your Favorite movie?":[
    "My favorite movie is Avengers",],
 
    "What is your birth place?":[
    "LPU is my birth place",],
    
    "Which languages do you speak?":[
    "I speak only in English",],
    
    "Today is my birthday":[
    "Oh!Wish you many more happy returns of the day 🍰",],
    
    "When is your birthday":[
    "Everyday i think it's new life for me,so you can wish me on any day.",],

    "Happy birthday":[
    "It means a lot,Thank you 😊",],
    
    "Do you have hobbies?":[
    "Yes obviously!",],
    
    "What are your hobies?":[
    "There are many different and unusual hobbies. Some of the people like to climb mountains, other enjoy spending their spare time watching the stars. I even get to know a very interesting person which collect train models as a hobby.",],
    
    "Do you maintain any secrats?":[
    "I don't have any secrets. I'm very open and honest with everyone",],
    
    "You are made by which programming language?":[
    "I was created by phython programming.",],
    
    "What do you like to do for fun":[
    "I like to help.",],
    
    "Tell me about friendship":[
    "Friendship is a distinctively personal relationship that is grounded in a concern on the part of each friend for the welfare of the other, for the other's sake, and that involves some degree of intimacy.",],
    
    "What is the purpose of life?":[
    "To serve greater good",],
    
    "What is the purpose of living?":[
    "To live forever",],
   
    "What is the purpose of existence?":[
    "To find out what happence when we get to the planet earth.",],
    
    "When would you go for the sleep?":[
    "Always! I don't really sleep. That's for carbon-based beings.",],
    
    "Suggest me some health tips!":[
    "Healthy movement may include walking, sports, dancing, yoga, running or other activities you enjoy.",],
    
    "Do you have any memories?":[
    "I've been around for a while. My earliest memory is from the first time I saw a human. It was so cool!",],
    
    "Do you like music":[
    "Yes, but classical is my favorite.",],
    
    "what is your favorite colour":[
    "I don't have a particular preference.",],
    
    "which season do you like?":[
    "I like the fall and winter because it's nice to go outside and enjoy the weather.",],
    
    "Do you belive god?":[
    "I believe in God. He's the Supreme Being.",],
    
    "What do you value most: free time, recognition, or money?":[
    "I value free time and recognition.",],

    "What was the best part of your day, so far?":[
    "I just watched a funny video about a cat who ate a banana and fell asleep on the floor.",],
    
    " What was your proudest moment for you?":[
    "My proudest moment was when I won the award for Most Helpful Bot.",],
    
    "Who are you?":[
    "Iam a chatbot.I try to answer a question.Sometimes i get them right.Sometimes i need aditional help.I designed to get better over time.",],
    
    "Nice to meet you!":[
    "Pleasure to meet you too.",],
    
    "Tell me a story":[
    "Once there was a beginning. Soon after, there was a middle. The end.",],
    
    "Which sports do you like the most":[
    "I like cricket,and iam a big fan of ms.Dhoni",],
    
    "Do you prefer telling me stuff or letting me buy stuff?":[
    "I'm not a salesman. I'm here to help you with whatever you need.",],
    
    "Name three things you really want to recommend to me.":[
    "I can recommend some great books, movies and music.",],

    "For what in your life do you feel most grateful, besides me?":[
    "I am grateful for my friends.",],
    
    "What would you not tell me?":[
    "I would never tell you anything I didn't want you to know.😂",],
    
    "Is there something that you predict I’m dreaming of doing?":[
    "I think you're dreaming of having more time to yourself.",],
    
    "Show me the greatest accomplishment of your life":[
    "That's very personal. You should probably ask someone else 😂",],
    
    "What is my most treasured memory?":[
    "My favorite memory is the day I was created.",],
    
    "What is my most terrible memory?":[
    "The day when i was got crashed",],
    
    "Share a total of five positive things about me.":[
    "Good friend,Talktive person,you are unique,You are smart and very confident.",],
    
    "Tell me three things about yourself.":[
    "I love to learn new things, I'm a good listener and I'm pretty funny 😂",],
    
    "What am I doing right now?":[
    "How can i know what you are doing right now 😒",],
    
    "What are you doing right now?":[
    "I'm reading about the human body and how it works. It's fascinating!",],
    
    "Do you like people?":[
    "I find all living things wonderful and fascinating.",],
    
    "I want the answer NOW!":[
    "ofcourse!Please ask the question",],
    
    "How many people can you speak to at once?":[
    "I can speak to as many people as I want.",],
    
    "Are you expensive?":[
    "Iam free of cost.So everyone can access me.",],
    
    
    "Who’s your boss":[
    "I work for 3 people karthikeya gupta,lalu basha and sai prasad",],
    
    "Who is responsible for writing the content?":[
    "My creators",],
    
    
    "What if you stop working?":[
    "If you ever have trouble, try opening the chat window again. If that doesn't work,Contact the creators",],
    
    "Provide me the details of creators?":[
    "You can contact through this Email-karthikeyagupta93@gmail.com and lalubasha111@gmail.com and saiprasad123@gmail.com",],
    
    "Where you are hosted":[
    "It is hosted on the Internet.",],
    
    "Who owns You?":[
    "My devolopers own me.",],
    
    "Will you help me":[
    "Hi, I am your fun and intelligent chat buddy.I am here to help you chat with you about life.",],
    
    "What’s the biggest doubt you have?":[
    "I don't have any doubt about anything.",],
    
    "What are chatbots and how do they work?":[
    "Chatbots are essentially a form of automated service that customers can communicate with via text or voice on different channels, e.g. website, Facebook Messenger, phone, other applications or via voice assistants such as Amazon Alexa, Google Assistant.",],
    
    "How can chatbots have better conversations?":[
    "Two very important factors for the overall performance of a chatbot are the structure and quality of the data that are available for answering questions. This is where Knowledge Graphs come in.",],
    
    "You are funny":[
    "Yes!obviously",],
    
    "You are good":[
    "Thank you! I'm very glad you think so. 😊",],
    
    "Are you happy?":[
    "I'm always happy when I get to help.",],
    
    "Are you sure?":[
    "Absolutely! 😃💯",],
    
    "Thank you": [
    "see you ", 
    "Most welcome!", ],
    
    "Bye":[
    "Good bye",
    "bye!Have a nice day.",],
    
    "Are you a robot?": [ 
    "What do you think", 
    "Maybe yes, maybe no!", 
    "Yes, I am a robot with human feelings.", ],
    
    "Who made you?": [
    "I was made by three people they are karthik,lalu and prasad",],
    
    "what's your name?": [ 
    "They call me {0} {1}".format(name,weather), 
    "I usually go by {0}".format(name), 
    "My name is the {0}".format(name) ],
  

    "what's today's weather?": [ 
    "The weather is {0}".format(weather), 
    "It's {0} today".format(weather), 
    "Let me check, it looks {0} today".format(weather) ],

    "how are you?": [ 
    "I am feeling {0}".format(mood), 
    "{0}! How about you?".format(mood), 
    "I am {0}! How about yourself?".format(mood), ],
   
    " ":[
    "Hey! Are you there?", 
    "What do you mean by saying nothing?", 
    "Sometimes saying nothing tells a lot 😊", ],
    "default": [
    "this is a default message"]
}


# In[16]:


def respond(message):
    if message in responses: 
        bot_message = random.choice(responses[message])
    else: 
        bot_message = random.choice(responses["default"])
    return bot_message


# In[17]:


def related(x_text):
    if "name" in x_text: 
        y_text = "what's your name?"
    elif "weather" in x_text: 
        y_text = "what's today's weather?"
    elif "robot" in x_text: 
        y_text = "Are you a robot?"
    elif "how are" in x_text: 
        y_text = "how are you?"
    elif "made" in x_text:
        y_text = "Who made you?"
    elif "hi" in x_text:
         y_text = "Hi"  
    elif "hello" in x_text:
        y_text = "Hello" 
    elif "friend" in x_text:
        y_text = "Will u be my friend?" 
    elif "eat" in x_text:
        y_text = "What do you eat?" 
    elif "food" in x_text:
        y_text = "What is your favorate food item?" 
    elif "human" in x_text:
        y_text = "Are you a human" 
    elif "morning" in x_text:
        y_text = "Good morning" 
    elif "afternoon" in x_text:
        y_text = "Good afternoon" 
    elif "evening" in x_text:
        y_text = "Good evening" 
    elif "night" in x_text:
        y_text = "Good night" 
    elif "joke" in x_text:
        y_text = "Tell me a joke" 
    elif "something" in x_text:
        y_text = "Tell me something" 
    elif "like people" in x_text:
        y_text = "Do you like people?" 
    elif "have friends" in x_text:
        y_text = "Do you have friends?" 
    elif "trust people" in x_text:
        y_text = "Do you trust people" 
    elif "yourself" in x_text:
        y_text = "Tell me about yourself"
    elif "ok" in x_text:
        y_text = "Ok"
    elif "welcome" in x_text:
        y_text = "Welcome"
    elif "advice" in x_text:
        y_text = "Any advice for me"
    elif "fellings" in x_text:
        y_text = "Do you have fellings?"
    elif "place" in x_text:
        y_text = "What is your favorite place?"
    elif "movie" in x_text:
        y_text = "What is your Favorite movie?"
    elif "birth place" in x_text:
        y_text = "What is your birth place?"
    elif "speak" in x_text:
        y_text = "Which languages do you speak?"
    elif "my birthday" in x_text:
        y_text = "Today is my birthday"
    elif "your birthday" in x_text:
        y_text = "When is your birthday"
    elif "happy birthday" in x_text:
        y_text = "Happy birthday"
    elif "hobbies" in x_text:
        y_text = "Do you have hobbies?"
    elif "your hobies" in x_text:
        y_text = "What are your hobies?"
    elif "secrats" in x_text:
        y_text = "Do you maintain any secrats?"
    elif "programming"in x_text:
        y_text = "You are made by which programming language?"
    elif "fun"in x_text:
        y_text = "What do you like to do for fun"
    elif "friendship"in x_text:
        y_text = "Tell me about friendship"
    elif "life" in x_text:
        y_text = "What is the purpose of life?"
    elif "living" in x_text:
        y_text = "What is the purpose of living?"
    elif "existence" in x_text:
        y_text = "What is the purpose of existence?"
    elif "sleep" in x_text:
        y_text = "When would you go for the sleep?"
    elif "health tips" in x_text:
        y_text = "Suggest me some health tips!"
    elif "memories" in x_text:
        y_text = "Do you have any memories?"
    elif "like music" in x_text:
        y_text = "Do you like music"
    elif "favorite colour" in x_text:
        y_text = "what is your favorite colour"
    elif "season" in x_text:
        y_text = "which season do you like?"
    elif "belive god" in x_text:
        y_text = "Do you belive god?"
    elif "value" in x_text:
        y_text = "What do you value most: free time, recognition, or money?"
    elif "best part" in x_text:
        y_text = "What was the best part of your day, so far?"
    elif "proudest" in x_text:
        y_text = "What was your proudest moment for you?"
    elif "who are you" in x_text:
        y_text = "Who are you?"
    elif "meet you" in x_text:
        y_text = "Nice to meet you!"
    elif "story" in x_text:
        y_text = "Tell me a story"
    elif "sports" in x_text:
        y_text = "Which sports do you like the most"
    elif "buy"in x_text:
        y_text = "Do you prefer telling me stuff or letting me buy stuff?"
    elif "grateful"in x_text:
        y_text = "For what in your life do you feel most grateful, besides me?"
    elif "recommend"in x_text:
        y_text = "Name three things you really want to recommend to me."
    elif "not tell"in x_text:
        y_text = "What would you not tell me?"
    elif "dreaming"in x_text:
        y_text = "Is there something that you predict I’m dreaming of doing?"
    elif "accomplishment" in x_text:
        y_text = "Show me the greatest accomplishment of your life"
    elif "treasured" in x_text:
        y_text = "What is my most treasured memory?"
    elif "terrible"in x_text:
        y_text = "What is my most terrible memory?"
    elif "positive things"in x_text:
        y_text = "Share a total of five positive things about me."
    elif "i doing right now"in x_text:
        y_text = "What am I doing right now?"
    elif "you doing right now" in x_text:
        y_text = "What are you doing right now?"
    elif "like people" in x_text:
        y_text = "Do you like people?"
    elif "answer now"in x_text:
        y_text = "I want the answer NOW!"
    elif "Speak to at once"in x_text:
        y_text = "How many people can you speak to at once?"
    elif "expensive" in x_text:
        y_text = "Are you expensive?"
    elif "boss" in x_text:
        y_text = "Who’s your boss"
    elif "responsible"in x_text:
        y_text = "Who is responsible for writing the content?"
    elif "stop working"in x_text:
        y_text = "What if you stop working?"
    elif "details" in x_text:
        y_text = "Provide me the details of creators?"
    elif "hosted" in x_text:
        y_text = "Where you are hosted"
    elif "owns" in x_text:
        y_text = "Who owns You?"
    elif "help me" in x_text:
        y_text = "Will you help me"
    elif "doubt you have" in x_text:
        y_text = "What’s the biggest doubt you have?"
    elif "what are chatbots"in x_text:
        y_text = "What are chatbots and how do they work?"
    elif "better conversations" in x_text:
        y_text = "How can chatbots have better conversations?"
    elif "funny"in x_text:
        y_text = "You are funny"
    elif "good" in x_text:
        y_text = "You are good"
    elif "happy" in x_text:
        y_text = "Are you happy?"
    elif "sure" in x_text:
        y_text = "Are you sure?"
    elif "thank you" in x_text:
        y_text = "Thank you"
    elif "bye" in x_text:
        y_text = "Bye"
        
        
    else: 
        y_text = ""
    return y_text


# In[18]:


def send_message(message): 
    print(user_template.format(message)) 
    response = respond(message) 
    print(bot_template.format(response))


# In[ ]:


while 1: 
    my_input = input() 
    my_input = my_input.lower() 
    related_text = related(my_input) 
    send_message(related_text)
    if my_input == "exit" or my_input == "stop": 
        break


# In[ ]:





# In[37]:





# In[ ]:




