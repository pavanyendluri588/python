# voice assistant
import pyttsx3 # for getting voice of assitant
import speech_recognition as sr # Setting up the function for listening
import datetime  # imported for getting date and time
import wikipedia  # pip install wikipedia
import webbrowser  # Setting up the function for opening browser
import os  # for interacting with opertaing system
import smtplib  # Setting up the function for sending email
import wolframalpha  # pip install wolframalpha
engine = pyttsx3.init('sapi5')  # sapi5 is the voice engine
voices = engine.getProperty('voices') # getting details of current voice
engine.setProperty('voice', voices[0].id)  # set the voice
rate = engine.getProperty('rate')  # getting details of current speaking rate
engine.setProperty('rate', 160) # changing speaking rate of voice
def speak(audio):  # Function for speaking the audio
    engine.say(audio) # Saying the audio
    engine.runAndWait()

def wishMe():  # Function for greeting
    hour = int(datetime.datetime.now().hour)  # Getting the current hour
    if hour >= 0 and hour <= 12: # Checking if the hour is between 0 and 12
        speak("Good Morning Sir")
    elif hour>= 12 and hour <18: # Checking if the hour is between 12 and 18
        speak("Good Afternoon Sir")
    else:                      # Checking if the hour is between 18 and 24
        speak("Good Evening Sir")
    speak("I am your Virtual Assistant. Please tell me how may I help you")

def TakeCommand():  # Function for taking command
    r = sr.Recognizer()  # Setting up the function for listening
    with sr.Microphone() as source:  
        print("Listening...") # Printing the message
        # r.pause_threshold = 1  
        audio = r.listen(source)
    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')  # Recognizing the audio
        print(f"User said: {query}\n")  # Printing the message
    except Exception as e:  # Checking if the audio is not recognized 
        print("Say that again please...")  # Printing the message
        return "None"  # Returning none
    return query # Returning the query

# wishMe() # Calling the function for greeting
if __name__ == "__main__":  # Checking if the file is being run as main file
    # wishMe()  # Calling the function for greeting
    while True:
        # query = TakeCommand().lower()
        query = "open notepad"
        # Logic for executing tasks based on query

        #------ for seraching in wikipedia of user's query --------
        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=4)
            speak("According to Wikipedia")
            speak(results)

#       ------ for opening application from os module ------
        elif "open chrome" in query:   # for chrome openinig
            speak("Opening Chrome")
            os.system("chrome")

        elif "open notepad" in query:  # for notepad opening
            speak("Opening Notepad")
            os.system("Notepad")

        elif "open paint" in query: # for paint opening
            speak("Opening Paint")
            os.system("mspaint")

        elif "open wordpad" in query:  # for wordpad opening
            speak("Opening Wordpad")
            os.system("wordpad")

        elif "open calculator" in query:  # for calculator opening
            speak("Opening Calculator")
            os.system("calc")

        elif "open excel" in query:  # for excel opening
            speak("Opening Excel")
            os.system("excel")

        elif "open files" in query:  # for files opening
            speak("Opening Files")
            os.system("explorer")
        
        elif "open sublime" in query:  # for sublime opening
            speak("Opening Sublime")
            os.system("sublime_text")

        elif "open vscode" in query:  # for vscode opening
            speak("Opening VSCode")
            os.system("code")

        elif "open powerpoint" in query:  # for powerpoint opening
            speak("Opening Powerpoint")
            os.system("powerpnt")

        elif "open whatsapp" in query: # for whatsapp opening
            speak("Opening Whatsapp")
            os.system("Whatsapp")

       # ------ for open site's in browser using webbrower module ------
        elif 'open youtube' in query:  # for youtube opening
            webbrowser.open("youtube.com") 
            speak("Opening Youtube")

        elif 'open google' in query:    # for google opening
            webbrowser.open("google.com")
            speak("Opening Google")

        elif 'open stackoverflow' in query: # for stackoverflow opening
            webbrowser.open("stackoverflow.com")
            speak("Opening Stackoverflow")

        elif 'open facebook' in query:  # for facebook opening
            webbrowser.open("facebook.com")
            speak("Opening Facebook")

        elif 'open gmail' in query:  # for gmail opening
            webbrowser.open("gmail.com")
            speak("Opening Gmail")

        elif 'open Linkedin' in query:  # for linkedin opening
            webbrowser.open("linkedin.com")
            speak("Opening Linkedin")

        elif 'open instagram' in query:  # for instagram opening
            webbrowser.open("instagram.com")
            speak("Opening Instagram")

        elif 'open twitter' in query: # for twitter opening
            webbrowser.open("twitter.com")
            speak("Opening Twitter")

        elif 'open whatsapp' in query: # for whatsapp opening
            webbrowser.open("web.whatsapp.com")
            speak("Opening Whatsapp")

        elif 'open amazon' in query:  # for amazon opening
            webbrowser.open("amazon.com")
            speak("Opening Amazon")

#       ------ for asking the time using datetime module ------
        elif 'time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S") # Getting the current time
            speak(f"Sir, the time is {strTime}")  
 
        elif 'search' in query:
            speak("What do you want to search for?")
            search = TakeCommand() # Taking the command
            url = "https://google.com/search?q=" + search # Creating the url for searching
            webbrowser.open(url)  # Opening the url
            speak("Here are some results")

        elif "who made you" in query or "who created you" in query or "who discovered you" in query:
            speak("I was built by Aishwarya and Mukesh")

        elif "who are you" in query:
            speak("I am your virtual assistant")

        elif "shutdown" in query:
            speak("do you really want to shutdown")
            reply = TakeCommand()
            if "yes" in reply:
                os.system('shutdown /s /t 1') # Shutting down the system
                speak("Shutting down")

        elif "restart" in query:
            speak("do you really want to restart")
            reply = TakeCommand()
            if "yes" in reply:
                os.system('shutdown /r /t 1') # Restarting the system
                speak("Restarting") 

        elif 'good bye' in query or 'bye' in query or 'exit' in query or 'quit' in query:
            speak("Bye Sir, have a good day.")
            break
        

        elif "play music" in query:
            speak("Playing Music")  
            music = 'D:\\Entertanimant\\music'  # Setting the path for the music
            songs = os.listdir(music) # Getting the list of songs
            os.startfile(os.path.join(music, songs[0])) # Playing the music

#       ------ asking consptual questions using wolframaplha api ------
        elif 'ask' in query:
            speak('What do you want to know?')
            question = TakeCommand()
            app_id = "JGYHYT-X39EKGR9QA"
            client = wolframalpha.Client('R2K75H-7ELALHR35X')
            res = client.query(question)
            answer = next(res.results).text
            speak(answer)
            print(answer)
