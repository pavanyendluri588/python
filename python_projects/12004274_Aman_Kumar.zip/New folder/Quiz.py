score = 0
score = int(score)

name = input("What is your name:")
name = name.title()
print("""\nHello {}, Welcome to Quiz. 
You will be presented with 5 questions.\n""".format(name))

print("Question1\n")
print("""Which type of Programming does Python support?
1) object-oriented programming
2) structured programming
3) functional programming
4) all of the mentioned\n""")

answer1 = "4"
response1 = input("Your answer is: ")

if (response1 != answer1):
    print("\nSorry, that is incorrect!")
else:
    print("\nWell done! " + response1 + " is correct!")
    score = score + 1

print("Your current score is " + str(score) + " out of 5\n")

print("Question2\n")
print("""What will be the output of the following Python code?
x = 'abcd'
for i in x:
    print(i.upper())

1) a B C D
2) A B C D
3) error
4) a b c d\n""")

answer2 = "2"
response2 = input("Your answer is:")

if (response2 != answer2):
    print("\nSorry, that is incorrect!")
else:
    print("\nWell done! " + response2 + " is correct!")
    score = score + 1

print("Your current score is " + str(score) + " out of 5\n")

print("Question3\n")
print("""What will be the output of the following Python code snippet?

for i in [1, 2, 3, 4][::-1]:
    print (i)
1) 4 3 2 1
2) error
3) 1 2 3 4
4) none of the mentioned\n""")

answer3 = "1"
response3 = input("Your answer is:")

if (response3 != answer3):
    print("\nSorry, that is incorrect!")
else:
    print("\nWell done! " + response3 + " is correct!")
    score = score + 1

print("Your current score is " + str(score) + " out of 5")

print("Question4\n")
print("""What will be the output of the following Python program?

i = 0
while i < 5:
    print(i)
    i += 1
    if i == 3:
        break
else:
    print(0)
1) error
2) 0 1 2 0
3) 0 1 2
4) none of the mentioned\n""")

answer4 = "3"
response4 = input("Your answer is:")

if (response4 != answer4):
    print("\nSorry, that is incorrect!")
else:
    print("\nWell done! " + response4 + " is correct!")
    score = score + 1

print("Your current score is " + str(score) + " out of 5")

print("Question5\n")
print("""Which of the following is a Python tuple?
1) [1, 2, 3]
2) (1, 2, 3)
3) {1, 2, 3}
4) {}\n""")

answer5 = "2"
response5 = input("Your answer is:")

if (response5 != answer5):
    print("\nSorry, that is incorrect!")
else:
    print("\nWell done! " + response5 + " is correct!\n\n")
    score = score + 1

print("Your total score is " + str(score) + " out of 5\n")
print("Thank you for playing this Quiz {}".format(name))      
