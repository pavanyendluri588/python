'''Python Project: MORSE CODE TRANSLATOR
   CA1
   SUBMITTED BY: ADITI
   REGISTRATION NO: 12015588
'''

# import all functions from the tkinter
from tkinter import *
from tkinter import messagebox

# Create a GUI window
root = Tk()

# geometry,bg color, heading of the gui window
# geometry is widthxhieght
root.geometry("300x400")
root.minsize(250,250)
root.maxsize(500,500)
root.title("Morse Code Translator")
headinglabel = Label(root, text = 'Morse Code Translator',
	fg = 'White', bg = "black")
headinglabel.grid(row = 0, column = 1)
root.configure(background = 'black')

# create and initialize variables
variable1 = StringVar(root)
variable2 = StringVar(root)
variable1.set("lanuage1")
variable2.set("language2")


# Dictionary representing the morse code chart
MORSE_CODE_DICT = { 'A':'.-', 
                    'B':'-...',
					'C':'-.-.', 
					'D':'-..', 
					'E':'.',
					'F':'..-.', 
					'G':'--.', 
					'H':'....',
					'I':'..', 
					'J':'.---', 
					'K':'-.-',
					'L':'.-..', 
					'M':'--', 
					'N':'-.',
					'O':'---', 
					'P':'.--.', 
					'Q':'--.-',
					'R':'.-.', 
					'S':'...', 
					'T':'-',
					'U':'..-', 
					'V':'...-', 
					'W':'.--',
					'X':'-..-', 
					'Y':'-.--', 
					'Z':'--..',
					'1':'.----', 
					'2':'..---', 
					'3':'...--',
					'4':'....-', 
					'5':'.....', 
					'6':'-....',
					'7':'--...', 
					'8':'---..', 
					'9':'----.',
					'0':'-----', 
					', ':'--..--', 
					'.':'.-.-.-',
					'?':'..--..', 
					'/':'-..-.', 
					'-':'-....-',
					'(':'-.--.', 
					')':'-.--.-',
                     '\n':'\n'
					}

# clear both text areas 
def clearAll() :
	language1_field.delete(1.0, END)
	language2_field.delete(1.0, END)

# Functions below: 1. convert, encrypt, decrypt

# 1. Conversion from language1 to language2 
def convert() :

	# get input from textbox
	message = language1_field.get("1.0", "end")[:-1].upper()

	# check whether var1=var2, if it is then show error
	if variable1.get() == variable2.get() :
		messagebox.showerror("select different language")
		return

	elif variable1.get() == "English" and variable2.get() == "Morse" :

		# function call 
		rslt = encrypt(message)

	elif variable1.get() == "Morse" and variable2.get() == "English" :

		# function call 
		rslt = decrypt(message)

	else :
		# Error message
		messagebox.showerror("choose valid language")
		return
	
	# put content of var1 into text area
	language2_field.insert('end -1 chars', rslt)
		
#Encryption according to morse dictionary
def encrypt(message):
	cipher = ''
	for letter in message:
		if letter != ' ':

			# adds diffreent characters and checks for spaces
			cipher += MORSE_CODE_DICT[letter] + ' '
		else:
			# 1 space implies diff char, 2 imply diff words
			cipher += ' '

	return cipher

# Decrypt Morse to english
def decrypt(message):

	# extra space added at the end to access the
	# last morse code
	message += ' '

	decipher = ''
	citext = ''
	for letter in message:

		# check space
		if (letter != ' '):

			# counter to keep track of space
			i = 0

			# store morse of single char
			citext += letter

		# if space is there
		else:
			# if i = 1 implies new char
			i += 1

			# if i = 2 that means a new word
			if i == 2 :

				# adds space to separate words
				decipher += ' '
			else:

				#decrypt
				decipher += list(MORSE_CODE_DICT.keys())[
							list(MORSE_CODE_DICT .values()).index(citext)]
				citext = ''

	return decipher


# Driver code
if __name__ == "__main__" :
	
# Interface

	# Create a text area box
	# for filling or typing the information.
	language1_field = Text(root, height = 5, width = 25,
									font = "Helvetica 15")
	language2_field = Text(root, height = 5, width = 25,
									font = "Helvetica 15")
		
	# padx keyword argument used to set padding along x-axis .
	language1_field.grid(row = 1, column = 1, padx = 10)
	language2_field.grid(row = 5, column = 1, padx = 10)

	# list of language codes
	languageCode_list = ["English", "Morse"]

	# Drop down menu
	OptionMenu(root, variable1, *languageCode_list).grid(row = 2, column = 1, ipadx = 10)
	OptionMenu(root, variable2, *languageCode_list).grid(row = 3, column = 1, ipadx = 10)

	# Convert button for convert funvtion
	convert1 = Button(root, text = "Convert", bg = "gray", fg = "white",
								command = convert)
	
	convert1.grid(row = 4, column = 1)

	# Clear button for clear function
	clear2 = Button(root, text = "Clear", bg = "gray",
					fg = "white", command = clearAll)
	
	clear2.grid(row = 6, column = 1)
	# 
	root.mainloop()
