"""
house price prediction using linear  regression
"""
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import style


# checking if numpy is imported or not
if pd:
    print("pandas imported successfully")
else:
    print("pandas not imported")
# checking if numpy is imported or not
if np:
    print("numpy imported successfully")
else:
    print("numpy not imported")
# checking if seaborn is imported or not
if sns:
    print("seaborn imported successfully")
else:
    print("seaborn not imported")
# checking if plt is imported or not
if plt:
    print("plt imported successfully")
else:
    print("plt not imported")

# path of the dataset
path = r"house_price_data.csv"

# reading the csv file using pandas read_csv method
file_test = pd.read_csv(path)

# converting the dataset into dataframe
df = pd.DataFrame(file_test) 

# printing the first 10 rows of teh dataframe
print(df.head(10))  

# printing the last 10 roes of the dataframe
print(df.tail(10))  

# printing the columns names of datafram df
print(df.columns)

"""
Index(['Avg. Area Income', 'Avg. Area House Age', 'Avg. Area Number of Rooms',
       'Avg. Area Number of Bedrooms', 'Area Population', 'Price', 'Address'],
      dtype='object')
"""
print("============================")
#index returns the index of the df DataFrame
print("datagrame df index:\n",df.index)
"""
RangeIndex: 5000 entries, 0 to 4999
"""
print("=============================================================")
print("maximum in df")
print("""maximum in df["Avg. Area Income"].max():""",df["Avg. Area Income"].max())
print("""maximum in df["Avg. Area House Age"].max():""",df["Avg. Area House Age"].max())
print("""maximum in df["Avg. Area Number of Rooms"].max():""",df["Avg. Area Number of Rooms"].max())
print("""maximum in df["Avg. Area Number of Bedrooms"].max():""",df["Avg. Area Number of Bedrooms"].max())
print("""maximum in df["Area Population"].max():""",df["Area Population"].max())

print("==================")
print("minimum in df")
print("""minimum in df["Avg. Area Income"].max():""",df["Avg. Area Income"].min())
print("""minimum in df["Avg. Area House Age"].max():""",df["Avg. Area House Age"].min())
print("""minimum in df["Avg. Area Number of Rooms"].max():""",df["Avg. Area Number of Rooms"].min())
print("""minimum in df["Avg. Area Number of Bedrooms"].max():""",df["Avg. Area Number of Bedrooms"].min())
print("""minimum in df["Area Population"].max():""",df["Area Population"].min())
print("==============================================================")


#w
#seaborn Pairplot uses to get the relation between each and every variable present in df DataFrame.
sns.pairplot(df)
plt.title("pairplot of df DataFrame")#title of the graph
plt.show()


print("info of df DataFrame:")
df.info()
"""
df.info()
returns:
id-column name
Non-Null Count-number of not null values 
Dtype- datatypt of the column
"""
print("=======================================")
#describe() method returns statics of the df  DataFrame
print("statics of df DataFrame:\n",df.describe())
#================================================================
# Exploratory Data Analysis for House Price Prediction.
#================================================================

#w
#plot is used to  plot the values in df dataframe
df.plot()
plt.title("plot() of df DataFrame")
plt.show()


#corr () function used to calculate correlation coefficient of  df.
sns.heatmap(df.corr())
plt.title("heatmap of correlation coefficient df")
plt.show()

#loading model_input columns into X
X = df[['Avg. Area Income', 'Avg. Area House Age', 'Avg. Area Number of Rooms',
        'Avg. Area Number of Bedrooms', 'Area Population']]

#loading model_output columns into y
y = df['Price']
print("==========================================================")
print("X:\n", X)
print("==============")
print("Y:\n", y)
print("==============")
print("x shape:",X.shape)
print("==============")
print("y shape:",y.shape)
print("==========================================================")

sns.displot(X)
plt.title("input_dataset visualization")
plt.show()

#====================================================
# Split Data into Train, Test 
#====================================================

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=101)#train size=60%  ,  test size:40%
print("x_train shape:",X_train.shape,"\ty_train shape:",y_train.shape)
print("================\nx_test shape:",X_test.shape,"\ty_test shape:",y_test.shape)

#==================================================================
#Creating and Training the LinearRegression Model
#==================================================================

# from sclearn module in linear_model we are importing the linear regression
from sklearn.linear_model import LinearRegression

#loading the linear regression model 
lm = LinearRegression()

# loading the x_train,y_train dataframes into linear regression model
lm.fit(X_train, y_train)

#LinearRegression Model Evaluation
intercept=lm.intercept_
print("================")
print("intercept_:\n",intercept)

coeff_df = pd.DataFrame(lm.coef_, X.columns, columns=['Coefficient'])
print("========================================================")
print("coeff_df:\n",coeff_df)


#========================================================================
#Predictions from our Linear Regression Model
#========================================================================
predictions = lm.predict(X_test)
print("==============================================================")
print("predections:\n",predictions)
print("===============================================================")

print("y_test shape:",y_test.shape)
print("=================")
print("predictions shape:",predictions.shape)
sns.displot((y_test-predictions))
plt.title("y_test-predictions graph:")
plt.show()


#========================================================================
#model evalution
#=========================================================================
from sklearn import metrics
accuracy_score=metrics.r2_score(y_test,predictions)
print("=================================================================")
print("model evalution:")
print("accrucy of our linear regression model")
print('accuracy score:',accuracy_score*100,"%" )
print("=================================================================")
plt.scatter(y_test, predictions)
plt.title("predictions  of linear regression model:")
plt.xlabel("y_test")
plt.ylabel("predections")
plt.show()